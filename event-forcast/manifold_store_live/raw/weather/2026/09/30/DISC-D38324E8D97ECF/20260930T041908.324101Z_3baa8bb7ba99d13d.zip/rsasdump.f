C$$$  MAIN PROGRAM DOCUMENTATION BLOCK 
C                .      .    .                                       . 
C SUBPROGRAM:    RSASDUMP     TEXT DUMP OF GRID POINT FILE
C   PRGMMR: L. BENJAMIN       ORG: FSL        DATE: 04-11-15
C 
C ABSTRACT: 
C   DUMPS NETCDF GRID POINTS FILE TO TEXT FILE
C 
C PROGRAM HISTORY LOG: 
C   05-01-10  L. BENJAMIN ORIGINAL VERSION.
C
C USAGE:    RSASDUMP
C
C   INPUT FILES: (FOR THE ENTIRE PROGRAM)
C     PARFILE  - 'rsasdump.par'
C     INFILE   - INPUT NETCDF FILE NAME (FROM THE PARFILE)
C
C   OUTPUT FILES:
C     OUTFILE  - OUTPUT ASCII FILE (FROM THE PARFILE)
C
C SUBPROGRAMS CALLED: 
C     UNIQUE:  - M_GETLUN, M_LSTCHR, M_FRTCHR, MRDYXFLOAT, PSIJLL, 
C                REAL2CLJ
C     LIBRARY: - NETCDF LIBRARY:  NCPOPT, NCINQ, NCDINQ, NCCLOS
C
C REMARKS:
C  
C  OUTPUT DUMP FORMAT OPTIONS  
C     ------------------------------------------------------------------
C     READ IN THE PARAMTER FILE DEFINING LATITUDE AND LONGITUDE RANGES
C     TO BE FILTERED.
C       LINE 1 - HEADER
C       LINE 2 - HEADER
C       LINE 3 - HEADER
C       LINE 4 - INPUT FILE
C       LINE 5 - OUTPUT FILE
C       LINE 6 - NUMBER OF SIGNIFICANT DIGITS (max - 7)
C       LINE 7 - TEMPERATURE UNITS (F,C,K)
C       LINE 8 - WIND COMPONENT UNITS (M/S,KTS,MPH)
C       LINE 9 - PRESSURE UNITS (PA,MB)
C       LINE 10 - ELEVATION UNITS (M,F)
C       LINE 11 - FIELD SEPARATOR (S(SPACE),C(COMA))
C       LINE 12 - HEADER
C       LINE 13 - HEADER
C       LINE 14 - HEADER
C       LINE 15 - VARIABLE
C       LINE 16... - ADDITIONAL VARIABLES (NONE TO ALL)
C
C     VARIABLE LIST:
C       I     - Y GRID POINTS
C       J     - X GRID POINTS
C       T     - TEMPERATURE
C       TD    - DEW POINT
C       U     - U WIND COMPONENT
C       V     - V WIND COMPONENT
C       EPT   - EQUIVALENT POTENTIAL TEMPERATURE
C       P     - PRESSURE
C       ELEV  - TOPOGRAPHY
C       PT3   - 3-HR PRESSURE TENDENCY
C       THETA - POTENTIAL TEMPERATURE
C       DPD   - DEW POINT DEPRESSION
C       RMSLP - RSAS MEAN SEA LEVEL PRESSURE
C       MSLP  - NWS MEAN SEA LEVEL PRESSURE
C       ALT   - ALTIMETER
C       Q     - SPECIFIC HUMIDITY
C       LAT   - LATITUDE
C       LON   - LONGITUDE
C     ------------------------------------------------------------------
C
C ATTRIBUTES: 
C   LANGUAGE: FORTRAN 77 + EXTENSIONS
C   MACHINE: UNIX
C 
C$$$ 






      PROGRAM RSASDUMP


C     ------------------------------------------------------------------
C     INCLUDES AND COMMONS
C     ------------------------------------------------------------------
      IMPLICIT   NONE

      INCLUDE '/usr/local/netcdf/include/netcdf.inc'

C     ------------------------------------------------------------------
C     LOCAL
C     ------------------------------------------------------------------
      INTEGER SUCCESS_P
      INTEGER FAILURE_P
      INTEGER INV_TIME_P
      PARAMETER (SUCCESS_P = 0)
      PARAMETER (FAILURE_P = 1)
      PARAMETER (INV_TIME_P = 4)

      REAL SPVAL
      PARAMETER (SPVAL = -99999.)

      INTEGER MAXVARS,NUMY,NUMX
      PARAMETER (MAXVARS = 18)
      PARAMETER (NUMX = 580)
      PARAMETER (NUMY = 548)

      REAL DXM,LAT_PS,LON_PS,LAT_TRUE,X_POLE,Y_POLE,ROT_PS
      PARAMETER (DXM = 15000.00)
      PARAMETER (LAT_PS = 90.0)
      PARAMETER (LON_PS = -105.0)
      PARAMETER (LAT_TRUE = 60.0)
      PARAMETER (X_POLE = 3897800.)
      PARAMETER (Y_POLE = 9182641.)
      PARAMETER (ROT_PS = 0)

      CHARACTER*255 INFILE
      CHARACTER*255 OUTFILE
      CHARACTER*255 TMPSTRLNG
      CHARACTER*80 TMPSTR
      CHARACTER*1 DEBUG

      CHARACTER*28 VARCVALUE
      CHARACTER*225 LINE
      CHARACTER*225 TMPLINE
      INTEGER STATUS

      REAL  RDATA(NUMX,NUMY)


      INTEGER LUN,IOSTAT,I,NCIDI
      INTEGER NREC,J,K,N,NCIDF,IFILE,L,M_LSTCHR
      CHARACTER*1 FLDSP
      REAL LAT,LON
      INTEGER LIFC,LOFC,LSC,FIRSTCHR,LASTCHR,M_FRTCHR
      INTEGER TULC,WULC,PULC,EULC,VULC
      LOGICAL ISOPEN_NCIDI
      INTEGER NUMSD,X,Y
      REAL EUNITCNV,WUNITCNV,PUNITCNV,TUNITCNVMULT,TUNITCNVADD
      REAL DPDUNITCNVMULT,DPDUNITCNVADD
      REAL UNITCNVMULT,UNITCNVADD

      CHARACTER*(MAXNCNAM) VARNAM,DIMNAM
      INTEGER       NDIMS,NGATTS,RECDIM,DIMSIZ
      INTEGER       NVARS,NVDIMS,VARTYP,LENSTR,NVATTS,RCODE
      CHARACTER*5 VAR(MAXVARS),VARNAME

      CHARACTER*1 SPACER
      INTEGER  RHID, AVRHID,NUMVAR,II
      INTEGER LASTCHRLINE, SIZE, FIRSTDOT, NC,EOSD
      REAL MAXDATA(MAXVARS,NUMX,NUMY)

      
C     *****************************************************************
C     ****************** BEGIN OF GRID POINT DUMP *********************
C     *****************************************************************

      DEBUG = 'Y'
      ISOPEN_NCIDI = .FALSE.
      SPACER = ' '

C     -----------------------------------------------------------------
C     ASSUME FAILURE.
C     -----------------------------------------------------------------
      STATUS = FAILURE_P

C     ------------------------------------------------------------------
C     READ IN THE PARAMETER FILE DEFINING WHAT THE USER WANTS.
C       LINE 1 - INPUT FILE
C       LINE 2 - OUTPUT FILE
C       LINE 3 - NUMBER OF SIGNIFICANT DIGITS (max - 7)
C       LINE 4 - TEMPERATURE UNITS (F,C,K)
C       LINE 5 - WIND COMPONENT UNITS (M/S,KTS,MPH)
C       LINE 6 - PRESSURE UNITS (PA,MB)
C       LINE 7 - ELEVATION UNITS (M,F)
C       LINE 8 - FIELD SEPARATOR (S(SPACE),C(COMA))
C       LINE 9 - VARIABLE
C       LINE 10... - ADDITIONAL VARIABLES
C     VARIABLE LIST:
C       I,J,T,TD,U,V,EPT,P,ELEV,PT3,THETA,DPD,RMSLP,MSLP,ALT,Q,LAT,LON
C       
C     ------------------------------------------------------------------
      CALL M_GETLUN(LUN, 1)

      OPEN(UNIT=LUN,FILE='rsasdump.par',STATUS='OLD',IOSTAT=IOSTAT)
      IF(IOSTAT.NE.0)THEN
         WRITE(*,*)'  - OPEN FAILURE ON rsasdump.par'
         STATUS = IOSTAT
         GO TO 2000
      ENDIF

 101  FORMAT(A)
C COMMENT LINE
      READ(LUN,101,err=900,end=900)TMPSTR
C COMMENT LINE
      READ(LUN,101,err=900,end=900)TMPSTR
C COMMENT LINE
      READ(LUN,101,err=900,end=900)TMPSTR
C START CONTROL PARMS
      READ(LUN,101,err=900,end=900)TMPSTRLNG
      FIRSTCHR = M_FRTCHR(TMPSTRLNG,255)
      LASTCHR = INDEX(TMPSTRLNG(FIRSTCHR:255),' ')
      INFILE = TMPSTRLNG(FIRSTCHR:LASTCHR)
      LIFC = LASTCHR - FIRSTCHR + 1
      WRITE(*,*)'IN: ',INFILE(1:LIFC)

      READ(LUN,101,err=900,end=900)TMPSTRLNG
      FIRSTCHR = M_FRTCHR(TMPSTRLNG,255)
      LASTCHR = INDEX(TMPSTRLNG(FIRSTCHR:255),' ')
      OUTFILE = TMPSTRLNG(FIRSTCHR:LASTCHR)
      LOFC =  LASTCHR - FIRSTCHR + 1
      WRITE(*,*)'OUT: ',OUTFILE(1:LOFC)

C SIGN DIGITS
      READ(LUN,*,err=701,end=702)NUMSD
      IF(NUMSD.LT.1.OR.NUMSD.GT.7)THEN
         WRITE(*,*)'SIGNIFICANT DIGITS RANGE IS 1 TO 7.'
         GO TO 2000
      ENDIF      
      WRITE(*,*)'SIGNIFICANT DIGITS: ',NUMSD
      GO TO 703
 701  CONTINUE
      WRITE(*,*)'ERROR READING NUMBER OF SIGNIFICANT DIGITS: ',IOSTAT
      GO TO 2000
 702  CONTINUE
      WRITE(*,*)'NO NUMBER OF SIGNIFICANT DIGITS INPUT IN PAR FILE.'
      GO TO 2000
 703  CONTINUE

C TEMP UNITS
      READ(LUN,101,err=704,end=705)TMPSTR
      FIRSTCHR = M_FRTCHR(TMPSTR,80)
      LASTCHR = INDEX(TMPSTR(FIRSTCHR:80),' ')
      TULC =  LASTCHR - FIRSTCHR + 1
      DO II = FIRSTCHR,LASTCHR
C UPPER CASE
         IF(ICHAR(TMPSTR(II:II)).GE.97.AND.
     1        ICHAR(TMPSTR(II:II)).LE.122)
     1        TMPSTR(II:II) = CHAR(
     1        ICHAR(TMPSTR(II:II)) - 32)
      ENDDO

C VALIDITY AND CONVERSION UNITS
      IF(TULC.GT.4)THEN
         WRITE(*,*)'TEMPERATURE UNITS ALLOWED ARE: F,C,K'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'F')THEN
         TUNITCNVMULT = 1.8
         TUNITCNVADD = -459.67
         DPDUNITCNVMULT = 1.8
         DPDUNITCNVADD = 0
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'C')THEN
         TUNITCNVMULT = 1
         TUNITCNVADD = -273.15
         DPDUNITCNVMULT = 1
         DPDUNITCNVADD = 0
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'K')THEN
         TUNITCNVMULT = 1
         TUNITCNVADD = 0
         DPDUNITCNVMULT = 1
         DPDUNITCNVADD = 0
      ELSE
         WRITE(*,*)'TEMPERATURE UNITS ALLOWED ARE: F,C,K'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ENDIF
      WRITE(*,*)'TEMPERATURE: ',TMPSTR(FIRSTCHR:LASTCHR)
      GO TO 706
 704  CONTINUE
      WRITE(*,*)'ERROR READING TEMPERATURE UNITS: ',IOSTAT
      GO TO 2000
 705  CONTINUE
      WRITE(*,*)'NO TEMPERATURE UNITS INPUT IN PAR FILE.'
      GO TO 2000
 706  CONTINUE

C WIND UNITS
      READ(LUN,101,err=707,end=708)TMPSTR
      FIRSTCHR = M_FRTCHR(TMPSTR,80)
      LASTCHR = INDEX(TMPSTR(FIRSTCHR:80),' ')
      SIZE =  LASTCHR - FIRSTCHR + 1
      DO II = FIRSTCHR,LASTCHR
C UPPER CASE
         IF(ICHAR(TMPSTR(II:II)).GE.97.AND.
     1        ICHAR(TMPSTR(II:II)).LE.122)
     1        TMPSTR(II:II) = CHAR(
     1        ICHAR(TMPSTR(II:II)) - 32)
      ENDDO
C VALIDITY AND CONVERSION UNITS
      IF(SIZE.GT.4)THEN
         WRITE(*,*)'WIND UNITS ALLOWED ARE: M/S,KTS,MPH'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'M/S')THEN
         WUNITCNV = 1
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'KTS')THEN
         WUNITCNV = 2.2369*0.86898
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'MPH')THEN
         WUNITCNV = 2.2369
      ELSE
         WRITE(*,*)'WIND UNITS ALLOWED ARE: M/S,KTS,MPH'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ENDIF
      WRITE(*,*)'WIND: ',TMPSTR(FIRSTCHR:LASTCHR)
      GO TO 709
 707  CONTINUE
      WRITE(*,*)'ERROR READING WIND UNITS: ',IOSTAT
      GO TO 2000
 708  CONTINUE
      WRITE(*,*)'NO WIND UNITS INPUT IN PAR FILE.'
      GO TO 2000
 709  CONTINUE

C PRES UNITS
      READ(LUN,101,err=710,end=711)TMPSTR
      FIRSTCHR = M_FRTCHR(TMPSTR,80)
      LASTCHR = INDEX(TMPSTR(FIRSTCHR:80),' ')
      SIZE =  LASTCHR - FIRSTCHR + 1
      DO II = FIRSTCHR,LASTCHR
C UPPER CASE
         IF(ICHAR(TMPSTR(II:II)).GE.97.AND.
     1        ICHAR(TMPSTR(II:II)).LE.122)
     1        TMPSTR(II:II) = CHAR(
     1        ICHAR(TMPSTR(II:II)) - 32)
      ENDDO
C VALIDITY AND CONVERSION UNITS
      IF(SIZE.GT.4.)THEN
         WRITE(*,*)'PRESSURE UNITS ALLOWED ARE: PA,MB'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'PA')THEN
         PUNITCNV = 1
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'MB')THEN
         PUNITCNV = 0.01
      ELSE
         WRITE(*,*)'PRESSURE UNITS ALLOWED ARE: PA,MB'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ENDIF
      WRITE(*,*)'PRESSURE: ',TMPSTR(FIRSTCHR:LASTCHR)
      GO TO 712
 710  CONTINUE
      WRITE(*,*)'ERROR READING PRES UNITS: ',IOSTAT
      GO TO 2000
 711  CONTINUE
      WRITE(*,*)'NO PRES UNITS INPUT IN PAR FILE.'
      GO TO 2000
 712  CONTINUE

C ELEV UNITS
      READ(LUN,101,err=713,end=714)TMPSTR
      FIRSTCHR = M_FRTCHR(TMPSTR,80)
      LASTCHR = INDEX(TMPSTR(FIRSTCHR:80),' ')
      SIZE =  LASTCHR - FIRSTCHR + 1
      DO II = FIRSTCHR,LASTCHR
C UPPER CASE
         IF(ICHAR(TMPSTR(II:II)).GE.97.AND.
     1        ICHAR(TMPSTR(II:II)).LE.122)
     1        TMPSTR(II:II) = CHAR(
     1        ICHAR(TMPSTR(II:II)) - 32)
      ENDDO
C VALIDITY AND CONVERSION UNITS
      IF(SIZE.GT.4)THEN
         WRITE(*,*)'ELEVATION UNITS ALLOWED ARE: M,F'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'M')THEN
         EUNITCNV = 1
      ELSE IF(TMPSTR(FIRSTCHR:LASTCHR).EQ.'F')THEN
         EUNITCNV = 3.2808
      ELSE
         WRITE(*,*)'ELEVATION UNITS ALLOWED ARE: M,F'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:LASTCHR)
         GO TO 2000
      ENDIF
      WRITE(*,*)'ELEVATION: ',TMPSTR(FIRSTCHR:LASTCHR)
      GO TO 715
 713  CONTINUE
      WRITE(*,*)'ERROR READING ELEV UNITS: ',IOSTAT
      GO TO 2000
 714  CONTINUE
      WRITE(*,*)'NO ELEV UNITS INPUT IN PAR FILE.'
      GO TO 2000
 715  CONTINUE

C FIELD SEPARATOR
      READ(LUN,101,err=716,end=717)TMPSTR
      FIRSTCHR = M_FRTCHR(TMPSTR,80)
      DO II = FIRSTCHR,FIRSTCHR
C UPPER CASE
         IF(ICHAR(TMPSTR(II:II)).GE.97.AND.
     1        ICHAR(TMPSTR(II:II)).LE.122)
     1        TMPSTR(II:II) = CHAR(
     1        ICHAR(TMPSTR(II:II)) - 32)
      ENDDO
      IF(TMPSTR(FIRSTCHR:FIRSTCHR+1).EQ.'S')THEN
         SPACER = ' '
      ELSE IF(TMPSTR(FIRSTCHR:FIRSTCHR+1).EQ.'C')THEN
         SPACER = ','
      ELSE
         WRITE(*,*)'ONLY ALLOWED FIELD SEPARATORS "C" (COMMA) ',
     1        'or "S" (SPACE)'
     1        ,'  ENTERED: ',TMPSTR(FIRSTCHR:FIRSTCHR+1)
         GO TO 2000
      ENDIF
      WRITE(*,*)'FIELD SEPARATOR: >',SPACER,'<'
      GO TO 718
 716  CONTINUE
      WRITE(*,*)'ERROR READING FIELD SEPARATOR: ',IOSTAT
      GO TO 2000
 717  CONTINUE
      WRITE(*,*)'NO FIELD SEPARATOR IN PAR FILE.'
      GO TO 2000
 718  CONTINUE


C COMMENT LINES
      DO 825 I = 1, 3
         READ(LUN,101,err=822,end=822,IOSTAT=IOSTAT)TMPSTR
 822     CONTINUE
 825  CONTINUE

      NUMVAR = 0
      DO 725 I = 1, MAXVARS
C VARIABLES 
         TMPSTR = ' '
         READ(LUN,101,err=722,end=723,IOSTAT=IOSTAT)TMPSTR
         GOTO 727
 723     CONTINUE
         FIRSTCHR = M_FRTCHR(TMPSTR,80)
         LASTCHR = INDEX(TMPSTR(FIRSTCHR:80),' ')
         IF(LASTCHR.LT.FIRSTCHR)THEN
            IF(NUMVAR.EQ.0)THEN
               WRITE(*,*)'NO VARIABLES IN PAR FILE.'
               GO TO 2000
            ENDIF
            GO TO 726
         ENDIF
 727     CONTINUE
         FIRSTCHR = M_FRTCHR(TMPSTR,80)
         LASTCHR = INDEX(TMPSTR(FIRSTCHR:80),' ')
         VULC =  LASTCHR - FIRSTCHR
         IF(VULC.GT.0)THEN
            VARNAME = TMPSTR(FIRSTCHR:LASTCHR)
            DO II = 1,LASTCHR-FIRSTCHR+1
C     UPPER CASE
               IF(ICHAR(VARNAME(II:II)).GE.97.AND.
     1              ICHAR(VARNAME(II:II)).LE.122)
     1              VARNAME(II:II) = CHAR(
     1              ICHAR(VARNAME(II:II)) - 32)
            ENDDO
C VALIDITY
            IF(VULC.GT.5.OR.(
     1           VARNAME.NE.'T'.AND.
     1           VARNAME.NE.'TD'.AND.
     1           VARNAME.NE.'U'.AND.
     1           VARNAME.NE.'V'.AND.
     1           VARNAME.NE.'EPT'.AND.
     1           VARNAME.NE.'P'.AND.
     1           VARNAME.NE.'ELEV'.AND.
     1           VARNAME.NE.'PT3'.AND.
     1           VARNAME.NE.'THETA'.AND.
     1           VARNAME.NE.'DPD'.AND.
     1           VARNAME.NE.'RMSLP'.AND.
     1           VARNAME.NE.'MSLP'.AND.
     1           VARNAME.NE.'ALT'.AND.
     1           VARNAME.NE.'Q'.AND.
     1           VARNAME.NE.'LAT'.AND.
     1           VARNAME.NE.'LON'.AND.
     1           VARNAME.NE.'I'.AND.
     1           VARNAME.NE.'J'
     1           ))THEN
               IF(LASTCHR.NE.1)THEN
                  WRITE(*,*)'VARIABLES ALLOWED ARE: T,TD,U,',
     1                 'V,EPT,P,ELEV,PT3,THETA,DPD,RMSLP,MSLP,ALT,Q,'     
     1                 ,'LAT,LON,I,J  ENTERED: ',
     1                 TMPSTR(FIRSTCHR:LASTCHR),LASTCHR
                  GO TO 2000
               ENDIF
            ELSE
               IF(NUMVAR.LT.MAXVARS)THEN
                  NUMVAR = NUMVAR + 1
                  VAR(NUMVAR) = VARNAME
               ENDIF
            ENDIF
         ENDIF
         IF(IOSTAT.EQ.-1)THEN
            IF(NUMVAR.EQ.0)THEN
               WRITE(*,*)'NO VARIABLES IN PAR FILE.'
               GO TO 2000
            ENDIF
            GO TO 726
         ENDIF
         GO TO 724
 722     CONTINUE
         WRITE(*,*)'ERROR READING FOR VARIABLES: ',IOSTAT
         GO TO 2000
 724     CONTINUE
 725  CONTINUE
 726  CONTINUE

 401  FORMAT(3x,a)
 402  FORMAT(3X,A,F13.6)
      CLOSE(UNIT=LUN)

      DO I = 1, NUMVAR
         WRITE(*,*)'VAR: ',I,' ',VAR(I)
      ENDDO

C     ------------------------------------------------------------------
C     PROCESS INPUT FILE.
C     ------------------------------------------------------------------


C     ------------------------------------------------------------------
C     KEEP NETCDF ERRORS FROM KILLING THE PROGRAM.
C     ------------------------------------------------------------------
      CALL NCPOPT(0)

C     ------------------------------------------------------------------
C     OPEN THE INPUT FILE, GET THE NUMBER OF VARIABLES, THE NUMBER OF
C     RECORDS IN THE FILE, AND THE RECORD DIMENSION.  THEN READ IN THE 
C     LATITUDE AND LONGITUDE VARIABLES.
C     ------------------------------------------------------------------
      N = LEN(INFILE)
      L = M_LSTCHR(INFILE(1:N),N)
      NCIDI = NCOPN(INFILE(1:L), NCNOWRIT, RCODE)
      IF(RCODE .NE. SUCCESS_P)THEN
         WRITE(*,*)'  - ERROR OPENING FILE: ',INFILE(1:L),RCODE
         GO TO 900
      ENDIF
      ISOPEN_NCIDI = .TRUE.

         
      CALL NCINQ(NCIDI,NDIMS,NVARS,NGATTS,RECDIM,RCODE)
      IF(RCODE.NE.0)THEN
         WRITE(*,*)'  - NCINQ ERROR: ',RCODE
         GO TO 900
      ENDIF
      CALL NCDINQ(NCIDI,RECDIM,DIMNAM,NREC,RCODE)
      IF(RCODE.NE.0)THEN
         WRITE(*,*)'  - NCDINQ RECDIM ERROR: ',RCODE
         GO TO 900
      ENDIF


C     ------------------------------------------------------------------
C     WRITE OUT VARIABLES
C     ------------------------------------------------------------------
C     ------------------------------------------------------------------
C     OPEN THE OUTPUT FILE.
C     ------------------------------------------------------------------

      DO 72 J = 1, NREC
         DO 70 I = 1, NUMVAR
            DO Y = 1, NUMY
               DO X = 1, NUMX
                  RDATA(X,Y) = SPVAL
               ENDDO
            ENDDO
            UNITCNVMULT = 1
            UNITCNVADD = 0
C READ
            IF(VAR(I).EQ.'ELEV')THEN
               VARNAM = 'staticTopo'
               CALL MRDYXFLOAT(VARNAM,NCIDI,RECDIM,1,1,SPVAL,RDATA,
     1              STATUS,Y*X,EUNITCNV,UNITCNVADD)

               IF(STATUS.NE.0)THEN
                  WRITE(*,*)'- COULD NOT FIND ANY ',VARNAM,' VARS'
                  GO TO 900
               ENDIF
               DO Y = 1, NUMY
                  DO X = 1, NUMX
                     MAXDATA(I,X,Y) = RDATA(X,Y)
                  ENDDO
               ENDDO
            ELSE IF(VAR(I).EQ.'I')THEN
               DO Y = 1, NUMY
                  DO X = 1, NUMX
                     MAXDATA(I,X,Y) = X
                  ENDDO
               ENDDO
            ELSE IF(VAR(I).EQ.'J')THEN
               DO Y = 1, NUMY
                  DO X = 1, NUMX
                     MAXDATA(I,X,Y) = Y
                  ENDDO
               ENDDO
            ELSE IF(VAR(I).EQ.'LAT')THEN
               DO Y = 1, NUMY
                  DO X = 1, NUMX
                     CALL PSIJLL(X,Y,DXM,LAT_PS,LON_PS,LAT_TRUE,X_POLE,
     1                    Y_POLE,ROT_PS,LAT,LON)
                     MAXDATA(I,X,Y) = LAT
                  ENDDO
               ENDDO
            ELSE IF(VAR(I).EQ.'LON')THEN
               DO Y = 1, NUMY
                  DO X = 1, NUMX
                     CALL PSIJLL(X,Y,DXM,LAT_PS,LON_PS,LAT_TRUE,X_POLE,
     1                    Y_POLE,ROT_PS,LAT,LON)
                     MAXDATA(I,X,Y) = LON
                  ENDDO
               ENDDO
            ELSE
               IF(VAR(I).EQ.'T')THEN
                  VARNAM = 't'
                  UNITCNVMULT = TUNITCNVMULT
                  UNITCNVADD = TUNITCNVADD
               ELSE IF(VAR(I).EQ.'TD')THEN
                  VARNAM = 'dpt'
                  UNITCNVMULT = TUNITCNVMULT
                  UNITCNVADD = TUNITCNVADD
               ELSE IF(VAR(I).EQ.'U')THEN
                  VARNAM = 'uw'
                  UNITCNVMULT = WUNITCNV
               ELSE IF(VAR(I).EQ.'V')THEN
                  VARNAM = 'vw'
                  UNITCNVMULT = WUNITCNV
               ELSE IF(VAR(I).EQ.'EPT')THEN
                  VARNAM = 'ept'
                  UNITCNVMULT = TUNITCNVMULT
                  UNITCNVADD = TUNITCNVADD
               ELSE IF(VAR(I).EQ.'P')THEN
                  VARNAM = 'p'
                  UNITCNVMULT = PUNITCNV
               ELSE IF(VAR(I).EQ.'PT3')THEN
                  VARNAM = 'pt3'
                  UNITCNVMULT = PUNITCNV
               ELSE IF(VAR(I).EQ.'THETA')THEN
                  VARNAM = 'pot'
                  UNITCNVMULT = TUNITCNVMULT
                  UNITCNVADD = TUNITCNVADD
               ELSE IF(VAR(I).EQ.'DPD')THEN
                  VARNAM = 'dpd'
                  UNITCNVMULT = DPDUNITCNVMULT
                  UNITCNVADD = DPDUNITCNVADD
               ELSE IF(VAR(I).EQ.'RMSLP')THEN
                  VARNAM = 'mmsp'
                  UNITCNVMULT = PUNITCNV
               ELSE IF(VAR(I).EQ.'MSLP')THEN
                  VARNAM = 'mslp'
                  UNITCNVMULT = PUNITCNV
               ELSE IF(VAR(I).EQ.'ALT')THEN
                  VARNAM = 'alti'
                  UNITCNVMULT = PUNITCNV
               ELSE IF(VAR(I).EQ.'Q')THEN
                  VARNAM = 'sh'
               ELSE
                  WRITE(*,*)'UNCODED VARNAM: ',VAR(I)
                  GO TO 70
               ENDIF

               CALL MRDYXFLOAT(VARNAM,NCIDI,RECDIM,1,1,SPVAL,RDATA,
     1              STATUS,Y*X,UNITCNVMULT,UNITCNVADD)

               IF(STATUS.NE.0)THEN
                  WRITE(*,*)'- COULD NOT FIND ANY ',VARNAM,' VARS'
                  GO TO 900
               ENDIF
               DO Y = 1, NUMY
                  DO X = 1, NUMX
                     MAXDATA(I,X,Y) = RDATA(X,Y)
                  ENDDO
               ENDDO

            ENDIF
 70      CONTINUE

         OPEN(UNIT=LUN,FILE=OUTFILE(1:LOFC),STATUS='UNKNOWN',
     1        IOSTAT=IOSTAT)
         IF(IOSTAT.NE.0)THEN
            WRITE(*,*)'  - OPEN FAILURE ON ',OUTFILE(1:LOFC)
            STATUS = IOSTAT
            GO TO 2000
         ENDIF
         
         DO Y = 1, NUMY
            DO X = 1, NUMX
               LINE = ' '
               DO I = 1, NUMVAR

                  CALL REAL2CLJ (MAXDATA(I,X,Y),VARCVALUE,NC,
     1                 STATUS,NUMSD)
                  LASTCHRLINE = M_LSTCHR(LINE,225)
 102              FORMAT(A,A,A)
                  IF(LASTCHRLINE.LE.1)THEN
                     WRITE(LINE,101)VARCVALUE(1:NC)
                  ELSE                     
                     WRITE(TMPLINE,102)LINE(1:LASTCHRLINE),SPACER,
     1                    VARCVALUE(1:NC)
                     LINE = TMPLINE
                  ENDIF
               ENDDO
               LASTCHRLINE = M_LSTCHR(LINE,225)
               WRITE(LUN,101)LINE(1:LASTCHRLINE)
            ENDDO
         ENDDO
 72   CONTINUE
      CLOSE(UNIT=LUN)

C     ------------------------------------------------------------------
C     FINISH UP.
C     ------------------------------------------------------------------
 900  CONTINUE


      IF(ISOPEN_NCIDI)THEN
         CALL NCCLOS(NCIDI,RCODE)
         ISOPEN_NCIDI = .FALSE.
      ENDIF

 2000 CONTINUE
      CLOSE(UNIT=LUN,IOSTAT=IOSTAT)

      END



C$$$  SUBPROGRAM DOCUMENTATION BLOCK
C                .      .    .                                       .
C SUBPROGRAM:    M_GETLUN    GET UNIQUE LOGICAL UNIT NUMBERS
C   PRGMMR: SMITH, TRACY     ORG: FSL/PROFS  DATE: 90-06-15
C
C ABSTRACT: THIS PROGRAM GETS UNIQUE LOGICAL UNIT NUMBERS FOR OPFILE
C   OR RETURNS THEM TO THE POOL FOR CLFILE.
C
C PROGRAM HISTORY LOG:
C
C
C USAGE:    CALL M_GETLUN(LUN,OPTN)
C   INPUT ARGUMENT LIST:
C     LUN      - INTEGER  LOGICAL UNIT NUMBER
C     OPTN     - INTEGER  CNCT=1, DSCT=2.
C                IF CONNECTING A FILE(CNCT) SET THE NUMBER TO
C                NEGATIVE SO IT WON'T BE USED UNTIL AFTER
C                DSCT SETS IT POSITIVE.
C
C   OUTPUT ARGUMENT LIST:
C     LUN      - INTEGER  LOGICAL UNIT NUMBER
C
C REMARKS:
C
C ATTRIBUTES:
C   LANGUAGE: FORTRAN-77
C   MACHINE:  NAS-9000
C$$$

       SUBROUTINE M_GETLUN(LUN,OPTN)
C* THIS PROGRAM GETS UNIQUE LOGICAL UNIT NUMBERS FOR OPFILE
C* OR RETURNS THEM TO THE POOL FOR CLFILE
       IMPLICIT   NONE
       INTEGER LUN,NUM(80),OPTN,CNCT,DSCT,I
       PARAMETER (CNCT=1,DSCT=2)
       SAVE NUM
CC
       DATA NUM/99,98,97,96,95,94,93,92,91,90,
     +            89,88,87,86,85,84,83,82,81,80,
     +            79,78,77,76,75,74,73,72,71,70,
     +            69,68,67,66,65,64,63,62,61,60,
     +            59,58,57,56,55,54,53,52,51,50,
     +            49,48,47,46,45,44,43,42,41,40,
     +            39,38,37,36,35,34,33,32,31,30,
     +            29,28,27,26,25,24,23,22,21,20/
C* START
       IF(OPTN.EQ.CNCT) THEN
        DO 10 I=1,80
         IF(NUM(I).GT.0) THEN
           LUN=NUM(I)
           NUM(I)=-NUM(I)
           GOTO 20
         ENDIF
10      CONTINUE
         PRINT*, 'NEED MORE THAN 80 UNIT NUMBERS'
20      CONTINUE

       ELSE IF(OPTN.EQ.DSCT) THEN
C* MAKE THE NUMBER AVAILABLE BY SETTING POSITIVE
         DO 30 I=1,80
           IF(LUN.EQ.-NUM(I)) NUM(I)=ABS(NUM(I))
30       CONTINUE
       END IF
       RETURN
       END
C$$$  SUBPROGRAM DOCUMENTATION BLOCK
C                .      .    .                                       .
C SUBPROGRAM:    M_LSTCHR    FIND LAST NON-BLANK CHARACTER IN A STRING
C   PRGMMR: M. BARTH         ORG: FSL        DATE: 97-08-14
C
C ABSTRACT: FIND LAST NON-BLANK CHARACTER IN A STRING
C
C PROGRAM HISTORY LOG:
C   97-08-14  M. BARTH         ORIGINAL PROGRAM
C
C USAGE:    I = M_LSTCHR(TEXT,N)
C
C INPUT ARGUMENT LIST:
C     TEXT       - CHARACTER           STRING TO BE SEARCHED
C     N          - INTEGER             NUMBER OF CHARACTERS TO SEARCH
C
C OUTPUT FUNCTIONAL RETURN:
C     M_LSTCHR   - INTEGER             INDEX (0 TO N) OF THE RIGHTMOST
C                                      NON-BLANK PRINTING CHARACTER
C
C ATTRIBUTES:
C   LANGUAGE: FORTRAN-77 + EXTENSIONS
C   MACHINE:  UNIX
C$$$
C
        INTEGER FUNCTION M_LSTCHR(TEXT,N)
C
        IMPLICIT   NONE

        CHARACTER*(*) TEXT
        INTEGER I,N
C
        DO 100 I = N,1,-1
                IF(ICHAR(TEXT(I:I)).GT.32.AND.
     $             ICHAR(TEXT(I:I)).LT.127.AND.
     $             ICHAR(TEXT(I:I)).NE.96)THEN
C
                        M_LSTCHR = I
                        RETURN
                ENDIF
 100    CONTINUE
C
        M_LSTCHR = 0
C
        RETURN
        END


C$$$  SUBPROGRAM DOCUMENTATION BLOCK
C                .      .    .                                       .
C SUBPROGRAM:    M_FRTCHR    FIND FIRST NON-BLANK CHARACTER IN A STRING
C   PRGMMR: L. BENJAMIN      ORG: FSL        DATE: 04-10-21
C
C ABSTRACT: FIND FIRST NON-BLANK CHARACTER IN A STRING
C
C PROGRAM HISTORY LOG:
C   04-10-21  L. BENJAMIN      ORIGINAL PROGRAM
C
C USAGE:    I = M_FRTCHR(TEXT,N)
C
C INPUT ARGUMENT LIST:
C     TEXT       - CHARACTER           STRING TO BE SEARCHED
C     N          - INTEGER             NUMBER OF CHARACTERS TO SEARCH
C
C OUTPUT FUNCTIONAL RETURN:
C     M_FRTCHR   - INTEGER             INDEX (0 TO N) OF THE LEFTMOST
C                                      NON-BLANK PRINTING CHARACTER
C
C ATTRIBUTES:
C   LANGUAGE: FORTRAN-77 + EXTENSIONS
C   MACHINE:  UNIX
C$$$
C
        INTEGER FUNCTION M_FRTCHR(TEXT,N)
C
        IMPLICIT   NONE

        CHARACTER*(*) TEXT
        INTEGER I,N
C
        DO 100 I = 1,N,1 
                IF(ICHAR(TEXT(I:I)).GT.32.AND.
     $             ICHAR(TEXT(I:I)).LT.127.AND.
     $             ICHAR(TEXT(I:I)).NE.96)THEN
C
                        M_FRTCHR = I
                        RETURN
                ENDIF
 100    CONTINUE
C
        M_FRTCHR = N
C
        RETURN
        END

C$$$  SUBPROGRAM DOCUMENTATION BLOCK
C                .      .    .                                       .
C SUBPROGRAM:    PSIJLL      CONVERTS I,J GRID COORDINATES TO LAT/LON
C   PRGMMR: STAN BENJAMIN    ORG: FSL/PROFS  DATE: 04-11-05
C
C ABSTRACT: CONVERT I,J GRID COORDINATES FOR A POLAR STEREO PROJECTION
C   TO LAT/LON.
C
C PROGRAM HISTORY LOG:
C   04-11-05  M. BARTH       ORIGINAL VERSION, BASED ON PRMCMP'S GRDGEN
C
C USAGE:    CALL PSIJLL (I,J,DXM,LAT_PS,LON_PS,LAT_TRUE,X_POLE,Y_POLE,
C                        ROT_PS,LAT,LON)
C
C   INPUT ARGUMENT LIST:
C     I        - INTEGER  I (X-DIMENSION) COORDINATE
C     J        - INTEGER  J (Y-DIMENSION) COORDINATE
C     DXM      - REAL     SIZE OF GRID BOX IN METERS
C     LAT_PS   - REAL     POLE LATITUDE (+- 90, DEPENDING ON HEMISPHERE)
C     LON_PS   - REAL     LONGITUDE MERIDIAN ALIGNED WITH X-AXIS
C     LAT_TRUE - REAL     LATITUDE AT WHICH X-Y SCALE IS TRUE
C     X_POLE   - REAL     X COORDINATE OF POLE
C     Y_POLE   - REAL     Y COORDINATE OF POLE
C     ROT_PS   - REAL     PROJECTION ROTATION CONSTANT
C
C   OUTPUT ARGUMENT LIST:
C     LAT      - REAL     LATITUDE OF I,J 
C     LON      - REAL     LONGITUDE OF I,J
C
C   SUBPROGRAMS CALLED:
C     NONE
C
C REMARKS: SEE COMMENTS ON STEREOGRAPHIC PROJECTIONS FROM NCAR
C   GRAPHICS MANUAL:
C
C   THE U,V PLANE IS TANGENTIAL TO THE GLOBE AT THE POINT
C   PHI(LAT_PS,LON_PS), WHICH TRANSFORMS TO THE ORIGIN, PHI'(0,0), 
C   OF THE U,V PLANE. ROT_PS IS THE ANGLE BETWEEN THE V-AXIS AND NORTH
C   AT PHI'.  LET P BE A POINT ON THE GLOBE AT AN ANGULAR DISTANCE, A,
C   FROM THE POINT PHI(LAT_PS,LON_PS).  LET B BE THE ANGLE BETWEEN
C   THE GREAT CIRCLE PHI-P AND THE MERIDIAN AT PHI.
C
C ATTRIBUTES:
C   LANGUAGE: FORTRAN-77 + EXTENSIONS
C   MACHINE:  UNIX
C$$$
CCCCCCCCCCCCC
C     ROTATION-CONSTANT = 1
C
C     I        - INTEGER  I (X-DIMENSION) COORDINATE
C     J        - INTEGER  J (Y-DIMENSION) COORDINATE
C     DXM      - REAL     SIZE OF GRID BOX IN METERS = 15000.00
C     LAT_PS   - REAL     POLE LATITUDE (+- 90, DEPENDING ON HEMISPHERE) = 90.00000
C     LON_PS   - REAL     LONGITUDE MERIDIAN ALIGNED WITH X-AXIS = -105.0000
C     LAT_TRUE - REAL     LATITUDE AT WHICH X-Y SCALE IS TRUE = 60.00000
C     X_POLE   - REAL     X COORDINATE OF POLE = 3897800.
C     Y_POLE   - REAL     Y COORDINATE OF POLE = 9182641.
C     ROT_PS   - REAL     PROJECTION ROTATION CONSTANT = 1
CCCCCCCCCCCCC
c$$$ 580            NX_S          Grid dimensions
c$$$ 548            NY_S
c$$$ 15000.00       DX_S
c$$$
c$$$ 1              PROJ_S        Projection:  0 - Lambert Conformal, 1 - Polar Stereo
c$$$
c$$$ 90.00000       LAT_PS_S      If Polar Stereo, these apply
c$$$ -105.0000      LON_PS_S
c$$$ 60.00000       LAT_TRUE_S
c$$$ 260.8533       I_POLE_S
c$$$ 613.1760       J_POLE_S
c$$$ 3897800.       X_POLE_S
c$$$ 9182641.       Y_POLE_S

C
      SUBROUTINE PSIJLL(I,J,DXM,LAT_PS,LON_PS,LAT_TRUE,X_POLE,Y_POLE,
     1                  ROT_PS,LAT,LON)


C**********************************************************************
C************************ MODULE   DECLARATIONS ***********************
C**********************************************************************
      IMPLICIT   NONE

C     -----------------------------------------------------------------
C     ARGUMENTS
C     -----------------------------------------------------------------
      INTEGER I,J
      REAL DXM,LAT_PS,LON_PS,LAT_TRUE,X_POLE,Y_POLE,ROT_PS,LAT,LON

C     -----------------------------------------------------------------
C     LOCAL VARIABLES
C     -----------------------------------------------------------------
      INTEGER SUCCESS_P
      INTEGER FAILURE_P
      INTEGER INV_TIME_P
      PARAMETER (SUCCESS_P = 0)
      PARAMETER (FAILURE_P = 1)
      PARAMETER (INV_TIME_P = 4)

      DOUBLE PRECISION  U
      DOUBLE PRECISION  V
      DOUBLE PRECISION  DELU
      DOUBLE PRECISION  DELV
      DOUBLE PRECISION  DLAT
      DOUBLE PRECISION  DLON
      DOUBLE PRECISION  PI, R, A, B
      DOUBLE PRECISION  U1, U2, V1, V2
      REAL  DX, I_POLE, J_POLE


C**********************************************************************
C************************ BEGIN OF MODULE PSIJLL **********************
C**********************************************************************

      I_POLE = (X_POLE + DXM)/DXM
      J_POLE = (Y_POLE + DXM)/DXM

      DX = DXM/1000.0
      PI = DACOS( - 1.0D0)

      A = (LAT_PS - LAT_TRUE)*PI/180.D0

C     *** 0.53995680 = KM / NAUTICAL MILE
C     *** 60.        = NAUTICAL MILES / DEGREE LATITUDE

      B = DX*.53995680D0/60.D0*PI/180.D0/2.D0/DCOS(LAT_TRUE*PI/180.D0)

      R = DTAN(A/2.D0)

      U1 = R*DSIN(B + ROT_PS)
      V1 = R*DCOS(B + ROT_PS)

C     ---------------------------------------------

      A = (LAT_PS - LAT_TRUE)*PI/180.D0

      B = -DX*.53995680D0/60.D0*PI/180.D0/2.D0/DCOS(LAT_TRUE*PI/180.D0)

      R = DTAN(A/2.D0)

      U2 = R*DSIN(B + ROT_PS)
      V2 = R*DCOS(B + ROT_PS)

      DELU = DABS(U1 - U2)

C     -----------------------------

      A = (LAT_PS-(LAT_TRUE+DX*.53995680D0/60.D0/2.D0))*PI/180.D0

      B = 0.0

      R = DTAN(A/2.D0)

      U1 = R*DSIN(B + ROT_PS)
      V1 = R*DCOS(B + ROT_PS)

C     ---------------------------------------------

      A = (LAT_PS-(LAT_TRUE-DX*.53995680D0/60.D0/2.D0))*PI/180.D0

      B = 0.0

      R = DTAN(A/2.D0)

      U2 = R*DSIN(B + ROT_PS)
      V2 = R*DCOS(B + ROT_PS)

      DELV = DABS(V2 - V1)

C     -----------------------------
C     COMPUTE X,Y (HERE CALLED U,V) OF THE I,J POINT

      U = DELU * (I - I_POLE)
      V = DELV * (J - J_POLE)

C     -----------------------------------------
C     COMPUTE LAT/LON 

      R = SQRT(U**2 + V**2)
      B = DATAN2(U, V) - ROT_PS
      A = 2.D0*DATAN(R)
      DLAT = LAT_PS - A*180.D0/PI
      DLON = 180.D0 + LON_PS - B*180.D0/PI
      IF (DLON .LT. -180.D0) DLON = DLON + 360.D0
      IF (DLON .GT. 180.D0) DLON = DLON - 360.D0
      LAT = DLAT
      LON = DLON

      RETURN
      END



C$$$  SUBPROGRAM DOCUMENTATION BLOCK
C                .      .    .                                       .
C SUBPROGRAM:    MRDYXFLOAT  READ A NUMERIC NETCDF VARIABLE
C   PRGMMR: M. BARTH         ORG: FSL        DATE: 99-09-16
C
C ABSTRACT: READ A NUMERIC NETCDF VARIABLE ON AN OPEN NETCDF FILE.
C
C PROGRAM HISTORY LOG:
C   99-09-16  M. BARTH    ORIGINAL VERSION
C   00-02-01  M. BARTH    REMOVED UNNEEDED DECLARATION OF STRCCOM.
C   00-02-09  M. BARTH    CHANGED LOCAL ARRAY DIMENSIONS TO USE
C                         MXDATA_P.
C   00-06-29  M. BARTH    CHECK FOR 99999 UNDOCUMENTED MISSING
C                         VALUES IN ACARS TURBULENCE VARIABLES.
C   01-07-06  M. BARTH    - ADDED VAR_NOTINDB_P ERROR RETURN.
C                         - RENAMED VNAME TO VRNAM SO MADISCOM
C                           COULD BE INCLUDED.
C                         - CHECK FOR -99999 UNDOCUMENTED MISSING
C                           VALUES IN AWIPS RAOB DATA.
C                         - CHECK FOR -1 UNDOCUMENTED MISSING
C                           VALUES IN AWIPS PROFILER DATA.
C                         - CHANGED HANDLING OF VRNAM IN MERROR CALLS
C                           TO CONFORM WITH G77 COMPILER
C   02-05-07  M. BARTH    CHECK FOR -9999 UNDOCUMENTED MISSING
C                         VALUES IN AWIPS MAP DATA.
C   02-05-29  M. BARTH    RESTRUCTURED TEMPORARY MEMORY ARRAY USAGE
C   02-07-29  M. BARTH    KEEP NAN'S OUT OF VARIABLES FOR FILLVALS.
C   03-10-10  M. BARTH    - CHECK FOR -99999 IN ALL AWIPS DATABASE
C                           FILES.
C                         - CHECK FOR 99999 UNDOCUMENTED MISSING
C                           VALUE IN ALL FSL AWIPS VARIABLES...
C   04-01-12  L. BENJAMIN - MODIFIED TO WORK ONLY FOR FLOAT VARIABLES, 
C                           USE INPUT DATA ARRAY INSTEAD OF TEMPORARY SPACE, 
C                           AND DATA VALUE CONVERTION FOR UNITS CHANGE
C
C USAGE:    CALL MRDYXFLOAT (VRNAM,NCID,RECDIM,STARTR,NRECS,SPVAL,
C                        VDATA,STATUS,RDATASIZE,UNITCNVMULT,UNITCNVADD)
C
C   INPUT ARGUMENT LIST:
C     VRNAM    - C       NETCDF VARIABLE NAME
C     NCID     - I       ID OF THE OPEN NETCDF QC FILE
C     RECDIM   - I       DIMENSION ID OF THE FILE'S RECORD DIMENSION
C     STARTR   - I       STARTING RECORD TO READ
C     NRECS    - I       NUMBER OF RECORDS TO READ
C     SPVAL    - R       DESIRED MISSING DATA FLAG
C     Y        - I       Y LOCATION
C     X        - I       X LOCATION
C
C   OUTPUT ARGUMENT LIST:
C     VDATA    - RA      REAL ARRAY WITH DATA AND SPVALS FILLED IN
C     STATUS   - I       SUCCESS_P OR ERROR CODE
C
C   INPUT FILES:
C     WHATEVER NETCDF FILE'S OPEN ON NCID.
C
C SUBPROGRAMS CALLED:
C     UNIQUE:    MERROR, M_LSTCHR
C     NETCDF:    NCVID, NCVINQ, NCDINQ, NCVGT, NCAGT, NCAINQ
C
C REMARKS:
C   - THE EXTENDED FORTRAN BYTE DATA TYPE IS USED.  IF THIS DOESN'T
C     COMPILE ON YOUR MACHINE, SEE IF INTEGER*1 IS AVAILABLE
C     AND CHANGE THIS ROUTINE TO USE THAT INSTEAD (THE PROBLEM
C     EXISTS WITH IRIX FORTRAN 90, AND THIS WILL SOLVE IT.)
C   - THIS ROUTINE IS ASSUMED TO BE CALLED BY A HIGHER-LEVEL MADIS
C     ROUTINE, SO NO ERROR CHECKING IS DONE ON THE INPUT VARIABLES.
C   - WHATEVER THE DATA TYPE OF THE VARIABLE, IT'S CONVERTED TO REAL.
C     THEREFORE, THIS ROUTINE SHOULDN'T BE USED FOR DOUBLE PRECISION
C     VARIABLES.
C   - THE TEST FOR -999 AS A MISSING VALUE IS NEEDED BECAUSE SOME
C     MESONET VARIABLES MISTAKENLY HAVE THIS VALUE (INSTEAD OF
C     THE LEGITIMATE MISSING_VALUE ATTRIBUTE).  ALSO NOTE THAT
C     AS THERE ARE NO BYTE DATA TYPES IN MESONET FILES WHERE THIS
C     BUG MAY BE EXTANT, WE DON'T BOTHER WITH THIS LOGIC IN THE
C     BYTE HANDLING BELOW.
C   - YET ANOTHER MESONET BUG CAUSES THE FUNKY USE OF DMISS BELOW.
C     THE MISSING_VALUE ATTRIBUTE MENTIONED IN THE PREVIOUS
C     REMARK ISN'T QUITE AS "LEGITIMATE" AS IT OUGHT TO BE...
C     INSTEAD, FOR FLOAT TYPES IT HAS BEEN SPECIFIED WITH A DOUBLE
C     PRECISION CONSTANT WHEN IT SHOULD BE A FLOAT TYPE.  THE
C     CODE IN THIS ROUTINE SHOULD HANDLE EITHER VERSION.
C   - LOCAL ARRAYS ARE DIMENSIONED TO MXDATA_P.  IF THIS NUMBER
C     PROVES TOO LARGE FOR A GIVEN COMPUTER, THEN PORTIONS OF THE
C     MADIS API (E.G., RAOB) THAT RELY ON THIS VOLUME OF DATA
C     BEING HANDLED IN A SINGLE NETCDF CALL MAY NEED TO BE
C     RESTRUCTURED!
C   - SEE madistmp.f FOR AN EXPLANATION OF HOW TEMPORARY STORAGE
C     IS HANDLED (ALL ARRAYS NAMED *TMP*).
C   - THE TEST FOR -99999 IN ALL AWIPS DATABASE FILES IS TO
C     COMPENSATE FOR THE COMMONLY-USED, UNDOCUMENTED MISSING DATA
C     FLAG THAT SHOWS UP ALL THE TIME IN AWIPS FILES...
C
C ATTRIBUTES:
C   LANGUAGE: FORTRAN-77 + EXTENSIONS
C   MACHINE:  UNIX
C$$$

      SUBROUTINE MRDYXFLOAT(VRNAM,NCID,RECDIM,STARTR,NRECS,SPVAL,RDATA,
     1                  STATUS,RDATASIZE,UNITCNVMULT,UNITCNVADD)

C     ------------------------------------------------------------------
C     INCLUDES AND COMMONS
C     ------------------------------------------------------------------
      IMPLICIT   NONE
      INCLUDE '/usr/local/netcdf/include/netcdf.inc'

C     ------------------------------------------------------------------
C     ARGUMENTS
C     ------------------------------------------------------------------
      CHARACTER*(*) VRNAM
      INTEGER NCID,RECDIM,STARTR,NRECS,STATUS,RDATASIZE
      REAL SPVAL,RDATA(*),UNITCNVMULT,UNITCNVADD

C     ------------------------------------------------------------------
C     LOCAL
C     ------------------------------------------------------------------
      INTEGER SUCCESS_P
      INTEGER FAILURE_P
      INTEGER INV_TIME_P
      PARAMETER (SUCCESS_P = 0)
      PARAMETER (FAILURE_P = 1)
      PARAMETER (INV_TIME_P = 4)

      INTEGER NC_READ_P
      PARAMETER (NC_READ_P = 2001)
      INTEGER VAR_NOTINDB_P
      PARAMETER (VAR_NOTINDB_P = 1005)
      INTEGER DIM_TOOSMALL_P
      PARAMETER (DIM_TOOSMALL_P = 4001)

      CHARACTER*(MAXNCNAM) VARNAM,DIMNAM,ERRVAR
      INTEGER I,J,K,L,N,RCODE,VARTYP,NVDIMS,VDIMS(MAXVDIMS),NVATTS,LN
      INTEGER DIMSIZ,START(MAXVDIMS),COUNT(MAXVDIMS),ATRTYP,M_LSTCHR
      REAL MISVAL1
      PARAMETER (MISVAL1 = -999.0)
      REAL ACARSMISS
      PARAMETER (ACARSMISS = 99999.0)
      REAL AWIPSMISS
      PARAMETER (AWIPSMISS = -99999.0)
      INTEGER NPNMISS
      PARAMETER (NPNMISS = -1)
      INTEGER MAPMISS
      PARAMETER (MAPMISS = -9999)
      LOGICAL HAVE_FILL,HAVE_MISS
      REAL RFILL
      INTEGER IFILL
      INTEGER*2 I2FILL
      BYTE BFILL
      EQUIVALENCE (RFILL,IFILL,I2FILL,BFILL)
      REAL RMISS
      INTEGER IMISS
      INTEGER*2 I2MISS
      BYTE BMISS
      DOUBLE PRECISION DMISS
      EQUIVALENCE (RMISS,IMISS,I2MISS,BMISS,DMISS)

      LOGICAL NODATA

      STATUS = NC_READ_P
      NODATA = .TRUE.

C     ------------------------------------------------------------------
C     GET THE VARIABLE ID FROM ITS NAME.  INQUIRE ABOUT ITS TYPE AND
C     DIMENSIONS.  FILL IN THE DIMENSIONS OF THE HYPERSLAB TO BE READ.
C     READ IT.  IF SUCCESSFUL, GET ITS FILL & MISSING ATTRIBUTES,
C     AND FILL IN THE CALLER'S ARRAY.
C     ------------------------------------------------------------------
      J = LEN(VRNAM)
      L = M_LSTCHR(VRNAM,J)
      ERRVAR = VRNAM(1:L)
      J = NCVID(NCID,VRNAM,RCODE)
      IF(RCODE.NE.0)THEN
         IF(RCODE.EQ.NCENOTVR)THEN
            WRITE(*,*)'MRDNUM: VARIABLE NOT IN SELECTED DATABASE'
            STATUS = VAR_NOTINDB_P
         ELSE
            WRITE(*,*)'MRDNUM: BAD NCVID - '//ERRVAR(1:L)
         ENDIF
         GO TO 900
      ENDIF
      CALL NCVINQ(NCID,J,VARNAM,VARTYP,NVDIMS,VDIMS,NVATTS,RCODE)
      IF(RCODE.NE.SUCCESS_P)THEN
         WRITE(*,*)'MRDNUM: BAD NCVINQ - '//ERRVAR(1:L)
         GO TO 900
      ENDIF
      IF(VARTYP.NE.NCBYTE.AND.VARTYP.NE.NCSHORT.AND.
     1   VARTYP.NE.NCLONG.AND.VARTYP.NE.NCFLOAT)THEN
         WRITE(*,*)'MRDNUM: BAD VARIABLE TYPE '//ERRVAR(1:L)
         GO TO 900
      ENDIF
      LN = 1
      DO 8551 K = 1, NVDIMS
         CALL NCDINQ(NCID,VDIMS(K),DIMNAM,DIMSIZ,RCODE)
         IF(RCODE.NE.SUCCESS_P)THEN
            WRITE(*,*)'MRDNUM: BAD NCDINQ - '//ERRVAR(1:L)
            GO TO 900
         ENDIF

         IF(K.LT.NVDIMS.OR.(NVDIMS.EQ.K.AND.VDIMS(K).NE.RECDIM))THEN
            START(K) = 1
            COUNT(K) = DIMSIZ
            LN = LN * DIMSIZ
         ELSE
            START(K) = STARTR
            COUNT(K) = NRECS
            LN = LN * NRECS
         ENDIF
 8551 CONTINUE
C     ------------------------------------------------------------------
C     IF TOO BIG FOR OUR LOCAL ARRAYS, RETURN WITH ERROR.
C     ------------------------------------------------------------------
      IF(LN.GT.RDATASIZE)THEN
         STATUS = DIM_TOOSMALL_P
         WRITE(*,*)'MRDNUM: EXCEEDED INTERNAL ARRAY SIZE - '//
     1               ERRVAR(1:L)
         GO TO 900
      ENDIF
      CALL NCVGT(NCID,J,START,COUNT,RDATA,RCODE)
      IF(RCODE.NE.SUCCESS_P)THEN
         WRITE(*,*)'MRDNUM: BAD NCVGT - '//ERRVAR(1:L)
         GO TO 900
      ENDIF
      NODATA = .FALSE.
      CALL NCAGT(NCID,J,'_FillValue',RFILL,RCODE)
      IF(RCODE.NE.SUCCESS_P)THEN
         HAVE_FILL = .FALSE.

C     NOTE WE HAVE TO PUT A VALID NUMBER INTO THE FILLVAL
C     VARIABLE FOR THE CASE OF IT DOESN'T EVEN EXIST -- GOT A
C     NAN THAT CAUSED PROBLEMS WHEN THIS WAS DONE ON A DEC ALPHA.

         RFILL = 0
      ELSE
         HAVE_FILL = .TRUE.
      ENDIF
      CALL NCAGT(NCID,J,'missing_value',RMISS,RCODE)
      IF(RCODE.EQ.SUCCESS_P)THEN
         HAVE_MISS = .TRUE.

C     ------------------------------------------------------------------
C     LOOK FOR AND FIX THE CASE OF A MISMATCH BETWEEN THE ATTRIBUTE
C     AND THE VARIABLE.  WE KNOW IT HAPPENS WITH MESONET FLOAT & SHORT
C     VARIABLES, AND WE KNOW IT REALLY DOESN'T HAPPEN ANYWHERE ELSE
C     (ESPECIALLY AS NO OTHER DATASET CURRENTLY USES THIS ATTRIBUTE).
C     GIVEN OUR HISTORY (BEST LEFT UNSPOKEN) WITH THE MESONET FILES,
C     IT'S BEST TO MAKE THE LOGIC GENERAL AND NOT STOP WITH THIS ONE
C     MISMATCH.
C     ------------------------------------------------------------------

         CALL NCAINQ(NCID,J,'missing_value',ATRTYP,NVATTS,RCODE)
         IF(RCODE.NE.SUCCESS_P)THEN
            WRITE(*,*)'MRDNUM: BAD NCAINQ - '//ERRVAR(1:L)
            GO TO 900
         ENDIF
         IMISS = IMISS
      ELSE
         HAVE_MISS = .FALSE.
         RMISS = 0
      ENDIF

      N = LN

C ONLY FLOAT
      DO 104 I = 1, N
         IF((HAVE_FILL.AND.RDATA(I).EQ.RFILL).OR.
     1        (HAVE_MISS.AND.(RDATA(I).EQ.RMISS.OR.
     2        RDATA(I).EQ.MISVAL1)).OR.NODATA)THEN
            RDATA(I) = SPVAL
         ELSE
            RDATA(I) = RDATA(I) * UNITCNVMULT + UNITCNVADD
         ENDIF

 104  CONTINUE


      STATUS = SUCCESS_P

 900  RETURN

      END

C$$$  SUBPROGRAM DOCUMENTATION BLOCK 
C                .      .    .                                       . 
C SUBPROGRAM:    REAL2CLJ    CREATE LEFT-JUSTFIED REAL NUMBER STRING
C   PRGMMR: M. BARTH         ORG: FSL        DATE: 01-11-27
C 
C ABSTRACT: WRITE ONE LEFT-JUSTIFIED REAL VALUE, WITH UP TO 7
C           SIGNIFICANT DIGITS, TO CALLER'S STRING.
C 
C PROGRAM HISTORY LOG: 
C   01-11-27  M. BARTH         ORIGINAL PROGRAM     
C   05-02-14  L. BENJAMIN      ADDED OVERFLOW AND LEADING BLANKS CHECK
C
C USAGE:    CALL REAL2CLJ (RVAL,VALUE,NC,STATUS)
C
C INPUT ARGUMENT LIST:
C     RVAL     - R       THE REAL NUMBER TO BE OUTPUT
C
C OUTPUT ARGUMENT LIST:
C     VALUE    - C       RVAL IN STRING FORMAT AS DESCRIBED ABOVE
C     NC       - I       NUMBER OF CHARACTERS USED IN VALUE
C     STATUS   - I       RETURN STATUS
C     NUMSD    - I       NUMBER OF SIGNIFICANT DIGITS
C 
C SUBPROGRAMS CALLED:
C     UNIQUE:  - LSTCHR, M_FRTCHR
C
C REMARKS:
C   MAXIMUM NUMBER OF CHARACTERS AFFECTED IN VALUE WILL BE 30.
C
C   ON MOST OPERATING SYSTEMS, NUMBERS >= 9,999,999.5 WILL BE
C   LIST-DIRECTED-OUTPUT IN E FORMAT (SCIENTIFIC NOTATION).
C  
C ATTRIBUTES: 
C   LANGUAGE: FORTRAN-77 + EXTENSIONS
C   MACHINE:  UNIX
C$$$ 


      SUBROUTINE REAL2CLJ (RVAL,VALUE,NC,STATUS,NUMSD)



C     *****************************************************************
C     ******************* MODULE   DECLARATIONS ***********************
C     *****************************************************************

      IMPLICIT   NONE

C     -----------------------------------------------------------------
C     ARGUMENTS
C     -----------------------------------------------------------------
      REAL RVAL
      CHARACTER*(*) VALUE
      INTEGER NC,STATUS,NUMSD

C     -----------------------------------------------------------------
C     LOCAL VARIABLES
C     -----------------------------------------------------------------
      INTEGER SUCCESS_P
      INTEGER FAILURE_P
      INTEGER INV_TIME_P
      PARAMETER (SUCCESS_P = 0)
      PARAMETER (FAILURE_P = 1)
      PARAMETER (INV_TIME_P = 4)

      INTEGER J,K,M,II,KK,M_LSTCHR,N
      INTEGER OVERFLOWM,M_FRTCHR,FIRSTCHR
      CHARACTER*30 TMP,TMP1,B30
      CHARACTER*7 FMT
      CHARACTER*7 FMTPLUS1
C     -----------------------------------------------------------------
C     DATA STATEMENTS (KEEP AT BOTTOM OF DECLARATIONS)
C     -----------------------------------------------------------------
      DATA B30/'                              '/      

C     *****************************************************************
C     ******************* BEGIN OF MODULE REAL2CLJ ********************
C     *****************************************************************

C     -----------------------------------------------------------------
C     DETERMINE HOW MANY CHARACTERS ARE IN THE CALLER'S STRING.
C     DON'T DEAL WITH MORE THAN 30.
C     -----------------------------------------------------------------
      N = LEN(VALUE)
      IF(N.GT.30)N = 30

C     -----------------------------------------------------------------
C     LEFT-JUSTIFY THE CHARACTER NUMERIC VALUE AT THE BEGINNING OF 
C     VALUE, WITH ONLY THE APPROPRIATE NUMBER OF SIGNIFICANT 
C     DIGITS.
C
C     ALSO NOTE THAT WE USE A LIST-DIRECTED WRITE TO A 30-CHARACTER
C     FIELD EVEN THOUGH WE ONLY WANT N MAX -- THIS IS TO TAKE CARE
C     OF THE MINIMUM LENGTH NEEDED FOR LIST-DIRECTED WRITES ON ANY
C     OPERATING SYSTEM.
C     -----------------------------------------------------------------
      STATUS = FAILURE_P
      TMP = B30
      TMP1 = B30
      VALUE = B30(1:N)
      WRITE(TMP,*,ERR=900)RVAL

C     -----------------------------------------------------------------
C     LEFT-JUSTIFY IT INTO TMP1.
C     -----------------------------------------------------------------
      K = M_LSTCHR(TMP,30)
      DO J = 1, 30
         IF(TMP(J:J).NE.' ')THEN
            TMP1(1:K-J+1) = TMP(J:K)
            GO TO 1
         ENDIF
      ENDDO
      GO TO 900

C     -----------------------------------------------------------------
C     FOR NUMBERS THAT HAVEN'T BEEN CONVERTED TO E FORMAT BY THE
C     LIST-DIRECTED WRITE, WE'LL TAKE ONLY THE FIRST 7 SIGNIFICANT 
C     DIGITS, UNLESS THERE ARE MORE THAN THAT BEFORE THE DECIMAL POINT, 
C     IN WHICH CASE WE'LL STOP AT THE DECIMAL POINT.
C
C     IF THE NUMBER IS IN E FORMAT, WE'LL TAKE ONE DIGIT BEFORE THE
C     DECIMAL POINT, AND 7 DIGITS AFTER.
C
C     IN BOTH CASES, WE'LL TAKE INTO ACCOUNT A MINUS SIGN, AND WE'LL
C     USE A RUN-TIME FORMAT TO WRITE THE VALUE OVER AGAIN INTO THE
C     PROPER SIZE FIELD.  THIS IS DONE, RATHER THAN MANIPULATING THE
C     STRING CREATED WITH THE LIST-DIRECTED WRITE, SO THAT WE ROUND
C     THE INSIGNIFICANT DIGITS, INSTEAD OF TRUNCATING THEM.
C     -----------------------------------------------------------------
 1    K = K - J + 1
      II = INDEX(TMP1(1:K),'E')
      IF(II.EQ.0)THEN

C     -----------------------------------------------------------------
C     FORMAT IS F(M+1).KK, WHERE:
C
C     M = NUMBER OF CHARACTERS BEFORE DECIMAL POINT
C     II = NUMBER OF SIGNIFICANT DIGITS + SPACE FOR MINUS SIGN IF NEEDED
C     M + KK <= II
C     -----------------------------------------------------------------
         M = INDEX(TMP1(1:K),'.') - 1
         IF(TMP1(1:1).NE.'-')THEN
            II = 7
         ELSE
            II = 8
         ENDIF
         IF(M.LT.II)THEN
            KK = II - M
         ELSE 
            KK = 0
         ENDIF
C NUMBER OF SIGNIIFCANT DIGITS ADJUSTMENT (0-7)
         KK = KK - 7 + NUMSD
         IF(KK.LT.0)KK=0
         
         IF(M+1+KK.GT.N)GO TO 900
         IF(M+1+KK.LT.10)THEN
            WRITE(FMT,2)M+1+KK,KK
            IF(M+1+KK+1.GE.10)THEN
               IF(KK.EQ.0)THEN
                  WRITE(FMTPLUS1,3)M+1+KK+1,KK
               ELSE
                  WRITE(FMTPLUS1,3)M+1+KK+1,KK-1
               ENDIF
               OVERFLOWM = 7
            ELSE
               IF(KK.EQ.0)THEN
                  WRITE(FMTPLUS1,2)M+1+KK+1,KK            
               ELSE
                  WRITE(FMTPLUS1,2)M+1+KK+1,KK-1            
               ENDIF
               OVERFLOWM = 6
            ENDIF

 2          FORMAT('(F',I1,'.',I1,')')
            NC = M + 1 + KK
            M = 6
         ELSE
            WRITE(FMT,3)M+1+KK,KK
            IF(KK.EQ.0)THEN
               WRITE(FMTPLUS1,3)M+1+KK+1,KK
            ELSE
               WRITE(FMTPLUS1,3)M+1+KK+1,KK-1
            ENDIF
 3          FORMAT('(F',I2,'.',I1,')')
            NC = M + 1 + KK
            M = 7
            OVERFLOWM = M
         ENDIF
      ELSE

C     -----------------------------------------------------------------
C     E FORMAT HAS TO BE USED.  THE LIST-DIRECTED OUTPUT WILL PRODUCED
C     THIS ONLY IF ABS(RVAL) >= 9,999,999.5, AND WE KNOW THAT THE FULL
C     7 DIGITS AFTER THE DECIMAL POINT WILL BE NEEDED.  THEREFORE, THE
C     ONLY DECISION IS WHETHER OR NOT TO INCLUDE SPACE FOR A MINUS
C     SIGN.
C     -----------------------------------------------------------------
         M = 7
         IF(TMP1(1:1).NE.'-')THEN
            WRITE(FMT,12)NUMSD
            WRITE(FMTPLUS1,12)NUMSD
 12         FORMAT('(E13.',I1,')')

            NC = 13 - 7 + NUMSD
         ELSE
            WRITE(FMT,13)NUMSD
            WRITE(FMTPLUS1,13)NUMSD
 13         FORMAT('(E14.',I1,')')
            NC = 14 - 7 + NUMSD
         ENDIF

      ENDIF

      WRITE(VALUE,FMT(1:M))RVAL

C     -----------------------------------------------------------------
C     CHECK FOR OVERFLOW CASES, IF SO USE THE LARGER FMT VERSION
C     -----------------------------------------------------------------
      IF(VALUE(1:1) .EQ. '*')THEN
         WRITE(VALUE,FMTPLUS1(1:OVERFLOWM))RVAL
      ENDIF

C     -----------------------------------------------------------------
C     CHECK FOR LEADING BLANKS
C     -----------------------------------------------------------------
      FIRSTCHR = M_FRTCHR(VALUE,N)
      IF(FIRSTCHR.GT.1)VALUE = VALUE(FIRSTCHR:N)

      FIRSTCHR = M_FRTCHR(VALUE,N)
      IF(FIRSTCHR.GT.1)THEN
         WRITE(*,*)VALUE,RVAL,FMT,FMTPLUS1,N
         CALL EXIT(0)
      ENDIF
      STATUS = SUCCESS_P

 900  RETURN
      END




C**---------------------------------------------------------------------
C**REQUIRED STANDARD FSL DISCLAIMER (NOVEMBER 2000)
C**---------------------------------------------------------------------
C**  OPEN SOURCE LICENSE/DISCLAIMER,  FORECAST SYSTEMS LABORATORY
C**  NOAA/OAR/FSL, 325 BROADWAY BOULDER, CO 80305
C**
C**  THIS SOFTWARE IS DISTRIBUTED UNDER THE OPEN SOURCE DEFINITION, 
C**  WHICH MAY BE FOUND AT http://www.opensource.org/osd.html.
C**
C**  IN PARTICULAR, REDISTRIBUTION AND USE IN SOURCE AND BINARY FORMS,
C**  WITH OR WITHOUT MODIFICATION, ARE PERMITTED PROVIDED THAT THE 
C**  FOLLOWING CONDITIONS ARE MET:
C**
C**  - REDISTRIBUTIONS OF SOURCE CODE MUST RETAIN THIS NOTICE, THIS LIST
C**    OF CONDITIONS AND THE FOLLOWING DISCLAIMER.
C**
C**  - REDISTRIBUTIONS IN BINARY FORM MUST PROVIDE ACCESS TO THIS 
C**    NOTICE, THIS LIST OF CONDITIONS AND THE FOLLOWING DISCLAIMER, AND
C**    THE UNDERLYING SOURCE CODE.
C**
C**  - ALL MODIFICATIONS TO THIS SOFTWARE MUST BE CLEARLY DOCUMENTED, 
C**    AND ARE SOLELY THE RESPONSIBILITY OF THE AGENT MAKING THE 
C**    MODIFICATIONS.
C**
C**  - IF SIGNIFICANT MODIFICATIONS OR ENHANCEMENTS ARE MADE TO THIS
C**    SOFTWARE, THE FSL SOFTWARE POLICY MANAGER 
C**    (softwaremgr.fsl@noaa.gov) BE NOTIFIED.
C**
C**  THIS SOFTWARE AND ITS DOCUMENTATION ARE IN THE PUBLIC DOMAIN AND 
C**  ARE FURNISHED "AS IS."  THE AUTHORS, THE UNITED STATES GOVERNMENT,
C**  ITS INSTRUMENTALITIES, OFFICERS, EMPLOYEES, AND AGENTS MAKE NO 
C**  WARRANTY, EXPRESS OR IMPLIED, AS TO THE USEFULNESS OF THE SOFTWARE
C**  AND DOCUMENTATION FOR ANY PURPOSE.  THEY ASSUME NO RESPONSIBILITY 
C**  (1) FOR THE USE OF THE SOFTWARE AND DOCUMENTATION; OR (2) TO 
C**  PROVIDE TECHNICAL SUPPORT TO USERS.
C**---------------------------------------------------------------------
